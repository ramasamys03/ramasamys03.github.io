// Copyright (c) 2011 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
// When the extension is installed or upgraded ...
chrome.runtime.onInstalled.addListener(function() {
  // Replace all rules ...
  chrome.declarativeContent.onPageChanged.removeRules(undefined, function() {
    // With a new rule ...
    chrome.declarativeContent.onPageChanged.addRules([
      {
        // That fires when a page's URL contains a 'www.nseindia.com/live_market/dynaContent/live_watch/option_chain/' ...
        conditions: [
          new chrome.declarativeContent.PageStateMatcher({
            pageUrl: { urlContains: 'www.nseindia.com/live_market/dynaContent/live_watch/option_chain/' },
          })
        ],
        // And shows the extension's page action.
        actions: [ new chrome.declarativeContent.ShowPageAction() ]
      }
    ]);
  });
});

var url_pattern = 'india.com/live_market/dynaContent/live_watch/option_chain/';
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
	var actualURL =tab.url;
    if (actualURL.indexOf(url_pattern) !== -1) {
        if (changeInfo.status === 'loading') { // Or 'complete'
             chrome.tabs.executeScript(tabId, {'file':'js/jquery.js'});
             chrome.tabs.executeScript(tabId, {'file':'js/jquery-ui.min.js'});
			       chrome.tabs.executeScript(tabId, {'file':'content_script.js'});
             chrome.pageAction.show(tabId);
        }
    } else {
        chrome.pageAction.hide(tabId);
    }
});
