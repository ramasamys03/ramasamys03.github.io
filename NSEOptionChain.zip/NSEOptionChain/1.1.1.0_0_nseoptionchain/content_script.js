// ----------------------------------------------- BEGIN -----------------------------------------------
// ------------------------------------------ BASIC STYLING --------------------------------------------
var COLUMNS = {
		C_CHART : 0,		
		C_PREMIUM: 1,
		C_OI: 2,
		C_CHANGE_OI: 3,
		C_VOLUME : 4,
		C_IV : 5,
		C_LTP: 6,
		C_NET_CHG: 7,
		C_BID_QTY : 8,
		C_BID_PRICE : 9,
		C_ASK_PRICE : 10,
		C_ASK_QTY : 11,		
		
		STRIKE_PRICE : 12,
		
		P_BID_QTY: 13,
		P_BID_PRICE : 14,
		P_ASK_PRICE : 15,
		P_ASK_QTY : 16,
		P_NET_CHG : 17,
		P_LTP: 18,
		P_IV : 19,
		P_VOLUME : 20,
		P_CHANGE_OI : 21,
		P_OI: 22,
		P_PREMIUM : 23,		
		P_CHART : 24
					
};

var styleA = document.createElement('link');
styleA.rel = 'stylesheet';
styleA.type = 'text/css';
styleA.href = chrome.extension.getURL('css/core.css');
(document.head||document.documentElement).appendChild(styleA);
var styleB = document.createElement('link');
styleB.rel = 'stylesheet';
styleB.type = 'text/css';
styleB.href = chrome.extension.getURL('css/jquery-ui.min.css');
(document.head||document.documentElement).appendChild(styleB);
var styleC = document.createElement('link');
styleC.rel = 'stylesheet';
styleC.type = 'text/css';
styleC.href = chrome.extension.getURL('css/jquery-ui.structure.min.css');
(document.head||document.documentElement).appendChild(styleC);
var styleD = document.createElement('link');
styleD.rel = 'stylesheet';
styleD.type = 'text/css';
styleD.href = chrome.extension.getURL('css/jquery-ui.theme.min.css');
(document.head||document.documentElement).appendChild(styleD);
$('#octable > tbody > tr > td.ylwbg').addClass('lightGreen').removeClass('ylwbg');
$('#octable > tbody > tr > td.nobg').addClass('lightRed').removeClass('nobg');
// -------------------------------------- ADD EXTRA TABLE CELL -----------------------------------------

 $('#octable').find('tr').eq(0).find('th').eq(0).attr('colspan',12); //CALL
 $('#octable').find('tr').eq(0).find('th').eq(2).attr('colspan',12); //PUT

$(function() {
	$('#wrapper_btm').css('width', '1300px');
	
	$("#OptionsTabs").tabs({
      collapsible: true
    }).removeClass('ui-widget-content');
    $( document ).tooltip({
	  items: '[data-title]',
	  track:true,
	  content: function(){
			var el = $(this);
			if ( el.is( "[title]" ) ) {
			  return el.attr("title");
			}
			if ( el.is( "[data-title]" ) ) {
			  return el.attr("data-title");
			}
	  },
      show: {
        effect: "slideDown",
        delay: 250
      }
    });
});

var titleText = 'Calculated using <b>Black-Scholes-Merton</b> model:<hr />The Black-Scholes formula (also called  Black-Scholes-Merton) is the widely used model for option pricing. It\'s used to calculate the theoretical value of options using current stock prices, expected dividends, the option\'s strike price, expected interest rates, time to expiration and expected volatility.<hr /><b>Disclaimer: </b>The prices calculated does not incorporate the dividends and use 10% as risk-free interest rates';
 $('#octable').find('tr').eq(1).each(function(){
        $(this).find('th').eq(0).after('<th data-title="' + titleText + '">Call Premium</th>');
		$(this).find('th').eq(22).after('<th data-title="' + titleText + '">Put Premium</th>');
		
		$(this).find('th').eq(23).after('<th data-title="' + titleText + '">PCR OI</th>');
		$(this).find('th').eq(24).after('<th data-title="' + titleText + '">PCR Vol</th>');
   });

$('#octable').find('tr:last').find('td').eq(0).before('<td></td>');
$('#octable').find('tr:last').find('td').eq(4).after('<td></td>');
$('#octable').find('tr:last').find('td').eq(6).attr('colspan',13);
$('#octable').find('tr:last').find('td').eq(6).after('<td></td>');
$('#octable').find('tr:last').find('td').eq(11).after('<td></td>');
//------------------------------------------------------------------------------------------------------
// ------------------------------------------------ END ------------------------------------------------


// ---------------------------------------- BEGIN CALCULATION ------------------------------------------
// ------------------------------------------ ADD VARIABLES --------------------------------------------
var rows= $('#octable tbody tr').not(':last').length;
var CumCE = 0;
var CumPE = 0;
var CValue = Number(0);
var PValue = 0;
var CallValue = 0;
var PutValue = 0;
var SumProCall = 0;
var SumProPut = 0;
var MinValue = 0;
var MaxPain = 0;
var TotalCallPut = 0;
var TotalCallOption = parseFloat($('#octable').find('tr:last').find('td').eq(2).text().replace(',', '').replace(',', '').replace(',', ''));
var TotalPutOption = parseFloat($('#octable').find('tr:last').find('td').eq(10).text().replace(',', '').replace(',', '').replace(',', ''));
var PCR = 0;
var CPR = 0;
var changeinPCR = 0;
var CurrentPCR_SP  = 0;
var PreviousPCR_SP = 0;
var ChangeinPCR_SP = 0;

var PercentChangeinCallOI = 0;
var PercentChangeinCallPrice = 0;
var PercentChangeinPutOI = 0;
var PercentChangeinPutPrice = 0;

var CallPriceChangeatATM = 0;
var PutPriceChangeatATM = 0;
var temp_CallPrice = 0;
var temp_PutlPrice = 0;
var HighestCallOI = [];
var HighestPutOI = [];
HighestCallOI[0] = 0;
HighestPutOI[0] = 0;
HighestCallOI[1] = 0; //row index
HighestPutOI[1] = 0;  //row index
HighestCallOI[2] = 0; //Strike Price
HighestPutOI[2] = 0; //Strike Price
HighestCallOI[3] = 0; //temp
HighestPutOI[3] = 0;  //temp

var fRowIndex = 0;
var lRowIndex = 0;
var OldValue = 0;
var MaxPainAdjusted = 0;

var CallBidPrice = 0;
var CallAskPrice = 0;
var PutBidPrice = 0;
var PutAskPrice = 0;

var changeinITMCALLOI = 0;
var changeinOTMCALLOI = 0;
var changeinITMPUTOI = 0;
var changeinOTMPUTOI = 0;

var ITMCALLOI = 0;
var OTMCALLOI = 0;
var ITMPUTOI = 0;
var OTMPUTOI = 0;

var callCount = 0;
var putCount = 0;
var callIV = 0;
var putIV = 0;
var avgCallIV = 0;
var avgPutIV = 0;

var callPrem = 0;
var putPrem = 0;
var arrBS = [];
var callGreek = '';
var putGreek = '';

var temp = 0;
var SP_ATM = 0;
var rowIdx_ATM = 0;

var OI_Price_Position = [];
var Sentiment = [];
var comments = [];
var stockStatus = 0;

var SumProCallVolume = 0;
var SumProPutVolume = 0;
var weightedSumCall = 0;
var weightedSumPut = 0;

var underlyingStock = $('div#wrapper_btm table:nth-of-type(1) td span:nth-of-type(1) b').text().split(/\s+/)[0];
var underlyingPrice = parseFloat($('div#wrapper_btm table:nth-of-type(1) td span:nth-of-type(1) b').text().split(/\s+/)[1]);
var timeLeft = ((Date.parse($('#date').val())-Date.now())/(24 * 60 * 60 * 1000))/365.2422;  //Time left in years

//----------------------------------------- VALIDATE VARIABLES ------------------------------------------------
if (isNaN(underlyingPrice)){
	underlyingPrice = 0;
  alert(underlyingStock + ' : ' + underlyingPrice);
}

$('#octable > tbody').find('tr').not(':last').each(function(){
		//---------------------------------------------------------------------------------------------------
		CValue = parseFloat($(this).find('td').eq(1).text().replace(',', '').replace(',', '').replace(',', ''));
		StrikeValue = parseFloat($(this).find('td').eq(11).text());
		
		if (isNaN(CValue)){
			CValue = 0;
		}
		else{
			CumCE = CumCE + CValue;
			CallValue = CumCE * StrikeValue;
		}
		SumProCall = SumProCall + (CValue * StrikeValue);

		

        $(this).find('td').eq(0).after('<td class=paleGreen>' + (CallValue - SumProCall)  + '</td>');

		if (fRowIndex == 0 && CValue != 0){
			fRowIndex = $(this).index();
		}
		//---------------------------------------------------------------------------------------------------
		//StrikeValue = parseFloat($(this).find('td').eq(12).text());
		PValue = parseFloat($(this).find('td').eq(22).text().replace(',', '').replace(',', '').replace(',', ''));
		if (isNaN(PValue)){
			PValue = 0;
		}
		else{
			CumPE = CumPE + PValue;
			PutValue = CumPE * StrikeValue;
		}

		SumProPut = SumProPut + (PValue * StrikeValue);
		
		var callOptionVolume =parseFloat($(this).find('td').eq(4).text().replace(',', '').replace(',', '').replace(',', ''));
		var putOptionVolume = parseFloat($(this).find('td').eq(20).text().replace(',', '').replace(',', '').replace(',', ''));
		
		
		if (isNaN(callOptionVolume) ||  isNaN(putOptionVolume)){
			SumProCallVolume = SumProCallVolume + 0 ;
			SumProPutVolume = SumProPutVolume + 0;
		}
		else{
			SumProCallVolume = SumProCallVolume + (CValue * callOptionVolume) ;
			SumProPutVolume = SumProPutVolume + (PValue * putOptionVolume);
		}
			
		
		$(this).find('td').eq(22).after('<td class=rosyBrown>' + (SumProPut - PutValue)  + '</td>');
		//---------------------------------------------------------------------------------------------------
		if (lRowIndex == 0 && (OldValue!=0 && OldValue == (SumProPut - PutValue))){
			lRowIndex = $(this).index();
		}
		OldValue = (SumProPut - PutValue);

		//Calculate MaxPain
		TotalCallPut = SumProPut - PutValue + CallValue - SumProCall;
		if (MinValue == 0){
			MinValue = TotalCallPut;
		}
		if (TotalCallPut <= MinValue){
			MinValue = TotalCallPut;
			MaxPain = StrikeValue;
		}


//-------------------------------------  CALCULATE CHANGE IN OPEN INTEREST FOR OTM AND ITM -----------------------------

		if (StrikeValue <= underlyingPrice){
			OTMPUTOI = OTMPUTOI + PValue;
			ITMCALLOI = ITMCALLOI + CValue;
		}
		else{
			ITMPUTOI = ITMPUTOI + PValue;
			OTMCALLOI = OTMCALLOI + CValue;
		}
		CValue = parseFloat($(this).find('td').eq(3).text().replace(',', '').replace(',', '').replace(',', ''));
		PValue = parseFloat($(this).find('td').eq(21).text().replace(',', '').replace(',', '').replace(',', ''));
		if(isNaN(CValue)){
			CValue= 0;
		}
		if(isNaN(PValue)){
			PValue= 0;
		}
		if (StrikeValue <= underlyingPrice){
			changeinOTMPUTOI = changeinOTMPUTOI + PValue;
			changeinITMCALLOI = changeinITMCALLOI + CValue;
		}
		else{
			changeinITMPUTOI = changeinITMPUTOI + PValue;
			changeinOTMCALLOI = changeinOTMCALLOI + CValue;
		}
$('#octable').find('tr:last').find('td').eq(3).html(changeinITMCALLOI + changeinOTMCALLOI);
$('#octable').find('tr:last').find('td').eq(9).html(changeinOTMPUTOI + changeinITMPUTOI);

//-------------------------------------------------  CALCULATE AVERAGE IV -----------------------------------------------
		CValue = parseFloat($(this).find('td').eq(5).text());
		PValue = parseFloat($(this).find('td').eq(19).text());

		if(isNaN(CValue)){
			CValue= 0;
		}
		else{
			callIV = callIV + CValue;
			callCount = callCount + 1;
		}
		if(isNaN(PValue)){
			PValue= 0;
		}
		else{
			putIV = putIV + PValue;
			putCount = putCount + 1;
		}
		avgCallIV = (callIV/callCount);
		avgPutIV = (putIV/putCount);
$('#octable').find('tr:last').find('td').eq(5).html((avgCallIV).toFixed(2));
$('#octable').find('tr:last').find('td').eq(7).html((avgPutIV).toFixed(2));
//------------------------------------------------------------------------------------------------------------------------

 }); //---------------- END OF TABLE TRAVERSING -------------------

   if (fRowIndex == 0 || fRowIndex<= (rows/5)){
	   fRowIndex = parseInt(rows/4);
   }

   if (lRowIndex == 0 || lRowIndex <= fRowIndex || lRowIndex >= (4*(rows/5))){
	   lRowIndex = parseInt(3*rows/4);
   }

// ----------------------------------------- CALCULATE PCR -------------------------------------------
	if (isNaN(TotalCallOption) || isNaN(TotalPutOption)){
		PCR = 0;
		CPR = 0;
	}
	else{
		PCR = TotalPutOption/TotalCallOption;
		CPR = TotalCallOption/TotalPutOption;
	}



   if (MaxPain == 0){
	   MaxPain = '';
   }
   else{
	   temp = MaxPain;
	   MaxPain = 'MaxPain = <b>' + MaxPain + '</b>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;';
   }
  // console.log($('#octable').find('tr:last').find('td').eq(4).text().replace(',', '').replace(',', '').replace(',', '') + ': Volume : ' + $('#octable').find('tr:last').find('td').eq(8).text().replace(',', '').replace(',', '').replace(',', ''))
   $('#octable').find('tr:last').find('td').eq(6).html(MaxPain + 'PCR OI= <b>' + PCR.toFixed(2) 
		     + '</b>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;PCR (ITM) = <b>' + parseFloat(ITMPUTOI/ITMCALLOI).toFixed(2)
		   	 + '</b>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;PCR (OTM) = <b>'+ parseFloat(OTMPUTOI/OTMCALLOI).toFixed(2) + '</b> </br>'
		  
		   	 + '</b>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;PCR Vol= <b>' + parseFloat($('#octable').find('tr:last').find('td').eq(8).text().replace(',', '').replace(',', '').replace(',', '')/$('#octable').find('tr:last').find('td').eq(4).text().replace(',', '').replace(',', '').replace(',', '')).toFixed(2)
		     + '</b>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;$wPCR Vol= <b>' + parseFloat(SumProPutVolume/SumProCallVolume).toFixed(2)
   			);
   MaxPain = temp;

   //---------------------------------------------------------------------------------------------------------------------------------------
   //---------------------------------------------------------------------------------------------------------------------------------------
/*
  CallFlag: True for Call/False for Put
  S: Spot Price
  X: Strike Price
  T: Time to expiration (in years)
  r: Risk-free rate
  v: Volatility
  This is the same one found in http://www.espenhaug.com/black_scholes.html
  but written with proper indentation and a === instead of == because it's
  faster, and it doesn't declare 5 useless variables (although if you really
  want to do it to have more elegant code I left a commented CND function in
  the end)
*/




function ndist(z) {
  return (1.0/(Math.sqrt(2*Math.PI)))*Math.exp(-0.5*z);
  //??  Math.exp(-0.5*z*z)
}

function N(z) {
  b1 =  0.31938153;
  b2 = -0.356563782;
  b3 =  1.781477937;
  b4 = -1.821255978;
  b5 =  1.330274429;
  p  =  0.2316419;
  c2 =  0.3989423;
  a=Math.abs(z);
  if (a>6.0) {return 1.0;}
  t = 1.0/(1.0+a*p);
  b = c2*Math.exp((-z)*(z/2.0));
  n = ((((b5*t+b4)*t+b3)*t+b2)*t+b1)*t;
  n = 1.0-b*n;
  if (z < 0.0) {n = 1.0 - n;}
  return n;
}

function black_scholes(S, X, r, t, vc, vp) {
// call = Boolean (to calc call, call=True, put: call=false)
// S = stock prics, X = strike price, r = no-risk interest rate
// v = volitility (1 std dev of S for (1 yr? 1 month?, you pick)
// t = time to maturity

// define some temp vars, to minimize function calls
  var sqt = Math.sqrt(t);
  var temp = 0;
  var cNd2;  //N(d2), used often
  var cNd1;  //n(d1), also used often
  var deltaC;  //The delta of the call option

  var pNd2;  //N(d2), used often
  var pNd1;  //n(d1), also used often
  var deltaP;  //The delta of the call option

  var ert;  //e(-rt), ditto
  var retArr = new Array(12);

  temp = (Math.log(S/X) + r*t);
  cd1 = temp/(vc*sqt) + 0.5*(vc*sqt);
  pd1 = temp/(vp*sqt) + 0.5*(vp*sqt);

  cd2 = cd1 - (vc*sqt);
  pd2 = pd1 - (vp*sqt);

  deltaC = N(cd1);
  deltaP = -N(-pd1);

  cNd2 = N(cd2);
  pNd2 = -N(-pd2);

  ert = Math.exp(-r*t);

  cNd1 = ndist(cd1);
  pNd1 = ndist(pd1);

  retArr[0] =  (S*deltaC - X*ert * cNd2);					//CALL PREMIUM
  retArr[1] = deltaC;										//DELTA
  retArr[2] = cNd1/(S*vc*sqt);								//GAMMA
  retArr[3] = S*sqt*cNd1;									//VEGA
  retArr[4] = -(S*vc*cNd1)/(2*sqt) - (r*X*ert*cNd2);		//THETA
  retArr[5] = X*t*ert*cNd2;									//RHO
  retArr[6] = (S*deltaP - X*ert * pNd2);					//PUT PREMIUM
  retArr[7] = deltaP;										//DELTA
  retArr[8] = pNd1/(S*vp*sqt);								//GAMMA
  retArr[9] = S*sqt*pNd1;;									//VEGA
  retArr[10] = -(S*vp*pNd1)/(2*sqt) - (r*X*ert*pNd2);		//THETA
  retArr[11] = X*t*ert*pNd2;								//RHO

  return retArr; // ( S*delta-X*ert *Nd2);

} //end of black_scholes

//----------------------------------- HIGHLIGHT MAXPAIN CELL ----------------------------------------------------

$('#octable > tbody').find('tr').not(':last').each(function(){
	StrikeValue = parseFloat($(this).find('td').eq(12).text());
  CallBidPrice = parseFloat($(this).find('td').eq(9).text());
  CallAskPrice = parseFloat($(this).find('td').eq(10).text());
  PutBidPrice =  parseFloat($(this).find('td').eq(14).text());
  PutAskPrice = parseFloat($(this).find('td').eq(15).text());
  if (isNaN(parseFloat($(this).find('td').eq(22).text())) || isNaN(parseFloat($(this).find('td').eq(2).text())))
  {
    CurrentPCR_SP = 0;
  }
  else {
    CurrentPCR_SP = parseFloat($(this).find('td').eq(22).text().replace(',', '').replace(',', '').replace(',', ''))/parseFloat($(this).find('td').eq(2).text().replace(',', '').replace(',', '').replace(',', ''));
    PreviousPCR_SP = (parseFloat($(this).find('td').eq(22).text().replace(',', '').replace(',', '').replace(',', '')) - (isNaN(parseFloat($(this).find('td').eq(21).text())) ? 0 : parseFloat($(this).find('td').eq(21).text().replace(',', '').replace(',', '').replace(',', ''))))/(parseFloat($(this).find('td').eq(2).text().replace(',', '').replace(',', '').replace(',', '')) - (isNaN(parseFloat($(this).find('td').eq(3).text())) ? 0.0001 : parseFloat($(this).find('td').eq(3).text().replace(',', '').replace(',', '').replace(',', ''))));
    ChangeinPCR_SP = (isNaN((CurrentPCR_SP - PreviousPCR_SP)/PreviousPCR_SP) ? 0 : ((CurrentPCR_SP - PreviousPCR_SP)/PreviousPCR_SP));
  }
  //--------------------- CALCULATE PERCENT CHANGE IN OPEN INTEREST AND PRICE --------------------------------------------------
  PercentChangeinCallOI = 0;
  if (isNaN(parseFloat($(this).find('td').eq(2).text())) || isNaN(parseFloat($(this).find('td').eq(3).text())))
  {
    PercentChangeinCallOI = 0;
  }
  else {
    PercentChangeinCallOI = parseFloat($(this).find('td').eq(3).text().replace(',', '').replace(',', '').replace(',', '')) / (parseFloat($(this).find('td').eq(2).text().replace(',', '').replace(',', '').replace(',', '')) - parseFloat($(this).find('td').eq(3).text().replace(',', '').replace(',', '').replace(',', '')));
  }
  PercentChangeinPutOI = 0;
  if (isNaN(parseFloat($(this).find('td').eq(21).text())) || isNaN(parseFloat($(this).find('td').eq(22).text())))
  {
    PercentChangeinPutOI = 0;
  }
  else {
    PercentChangeinPutOI = parseFloat($(this).find('td').eq(21).text().replace(',', '').replace(',', '').replace(',', '')) / (parseFloat($(this).find('td').eq(22).text().replace(',', '').replace(',', '').replace(',', '')) - parseFloat($(this).find('td').eq(21).text().replace(',', '').replace(',', '').replace(',', '')));
  }
  PercentChangeinCallPrice = 0;
  if (isNaN(parseFloat($(this).find('td').eq(6).text())) || isNaN(parseFloat($(this).find('td').eq(7).text())))
  {
    PercentChangeinCallPrice = 0;
  }
  else {
    PercentChangeinCallPrice = parseFloat($(this).find('td').eq(7).text().replace(',', '').replace(',', '').replace(',', '')) / (parseFloat($(this).find('td').eq(6).text().replace(',', '').replace(',', '').replace(',', '')) - parseFloat($(this).find('td').eq(7).text().replace(',', '').replace(',', '').replace(',', '')));
  }
  PercentChangeinPutPrice  = 0;
  if (isNaN(parseFloat($(this).find('td').eq(17).text())) || isNaN(parseFloat($(this).find('td').eq(18).text())))
  {
    PercentChangeinPutPrice = 0;
  }
  else {
    PercentChangeinPutPrice = parseFloat($(this).find('td').eq(17).text().replace(',', '').replace(',', '').replace(',', '')) / (parseFloat($(this).find('td').eq(18).text().replace(',', '').replace(',', '').replace(',', '')) - parseFloat($(this).find('td').eq(17).text().replace(',', '').replace(',', '').replace(',', '')));
  }
  //----------------------------------------------------------------------------------------------------------------------------
	if (StrikeValue == MaxPain){
		$(this).find('td').eq(12).addClass('MaxPain').removeClass('grybg');
	}
	if (StrikeValue == underlyingPrice){
		SP_ATM = StrikeValue;
		rowIdx_ATM = $(this).index();
    CallPriceChangeatATM = PercentChangeinCallPrice*100;
    PutPriceChangeatATM = PercentChangeinPutPrice*100;
	}
	else if (StrikeValue < underlyingPrice){
		temp = StrikeValue;
    temp_CallPrice = PercentChangeinCallPrice*100;
    temp_PutPrice = PercentChangeinPutPrice*100;
		rowIdx_ATM = $(this).index();
	}
	else if (StrikeValue > underlyingPrice && temp != 0){
		if ((StrikeValue - underlyingPrice) > (underlyingPrice - temp)){
			SP_ATM = temp;
      temp = 0;
      CallPriceChangeatATM = temp_CallPrice;
      PutPriceChangeatATM = temp_PutPrice;
		}
		else{
			SP_ATM = StrikeValue;
			rowIdx_ATM = rowIdx_ATM + 1;
      CallPriceChangeatATM = PercentChangeinCallPrice*100;
      PutPriceChangeatATM = PercentChangeinPutPrice*100;
		}
		temp = 0;
	}
//------------------ GET HIGHEST & LOWEST OI -----------------------------------------


if (HighestCallOI[0] == 0)
{
    if (isNaN(parseFloat($(this).find('td').eq(2).text().replace(',', '').replace(',', '').replace(',', ''))))
    {
      HighestCallOI[0] == 0;
    }
    else {
      if ( parseFloat($(this).find('td').eq(2).text().replace(',', '').replace(',', '').replace(',', '')) > HighestCallOI[0]){
        HighestCallOI[0] = parseFloat($(this).find('td').eq(2).text().replace(',', '').replace(',', '').replace(',', ''));
        HighestCallOI[1] = $(this).index();
        HighestCallOI[2] = parseFloat($(this).find('td').eq(12).text());
      }
    }
}
else {
  if ( parseFloat($(this).find('td').eq(2).text().replace(',', '').replace(',', '').replace(',', '')) > HighestCallOI[0]){
    HighestCallOI[0] = parseFloat($(this).find('td').eq(2).text().replace(',', '').replace(',', '').replace(',', ''));
    HighestCallOI[1] = $(this).index();
    HighestCallOI[2] = parseFloat($(this).find('td').eq(12).text());
  }
}

if (HighestPutOI[0] == 0)
{
    if (isNaN(parseFloat($(this).find('td').eq(22).text().replace(',', '').replace(',', '').replace(',', ''))))
    {
      HighestPutOI[0] == 0;
    }
    else {
      if ( parseFloat($(this).find('td').eq(22).text().replace(',', '').replace(',', '').replace(',', '')) > HighestPutOI[0]){
        HighestPutOI[0] = parseFloat($(this).find('td').eq(22).text().replace(',', '').replace(',', '').replace(',', ''));
        HighestPutOI[1] = $(this).index();
        HighestPutOI[2] = parseFloat($(this).find('td').eq(12).text());
      }
    }
}
else {
  if ( parseFloat($(this).find('td').eq(22).text().replace(',', '').replace(',', '').replace(',', '')) > HighestPutOI[0]){
    HighestPutOI[0] = parseFloat($(this).find('td').eq(22).text().replace(',', '').replace(',', '').replace(',', ''));
    HighestPutOI[1] = $(this).index();
    HighestPutOI[2] = parseFloat($(this).find('td').eq(12).text());
  }
}
//------------------ GET HIGHEST & LOWEST OI -----------------------------------------
	arrBS = black_scholes(underlyingPrice,StrikeValue,0.1,timeLeft,avgCallIV/100,avgPutIV/100);
	callPrem = arrBS[0];
	putPrem = arrBS[6];

	if (callPrem == 0){
		if (underlyingPrice > StrikeValue){
			callPrem = (underlyingPrice - StrikeValue).toFixed(2);
		}
		else{
			callPrem = 0.05;
		}
	}
	else{
		if (callPrem < 0.05){
			callPrem = 0.05;
		}
		else
		{

      if (callPrem > CallAskPrice)
      {
        callPrem = (CallAskPrice).toFixed(2);
      }
      else {
        callPrem = (Math.ceil(callPrem/0.05)*.05).toFixed(2);
      }

		}
	}

	if (putPrem == 0){
		if (underlyingPrice < StrikeValue){
			putPrem = (StrikeValue - underlyingPrice).toFixed(2);
		}
		else{
			putPrem = 0.05;
		}
	}
	else{
		if (putPrem < 0.05){
			putPrem = 0.05;
		}
		else
		{

      if (putPrem > PutAskPrice)
      {
        putPrem = (PutAskPrice).toFixed(2);
      }
      else {
        putPrem = (Math.ceil(putPrem/0.05)*.05).toFixed(2);
      }
		}
	}
	CallGreek = GreekStatement(arrBS[1], arrBS[2], arrBS[3], arrBS[4], arrBS[5]);
	PutGreek = GreekStatement(arrBS[7], arrBS[8], arrBS[9], arrBS[10], arrBS[11]);
  MaxPainAdjusted = ((CPR * HighestPutOI[2]) + (PCR * HighestCallOI[2]))/(PCR + CPR);

	$(this).find('td').eq(1).html(callPrem);
	$(this).find('td').eq(1).attr('data-title',CallGreek);
  $(this).find('td').eq(2).attr('data-title',(PercentChangeinCallOI*100).toFixed(2) + '%');
  $(this).find('td').eq(6).attr('data-title',(PercentChangeinCallPrice*100).toFixed(2) + '%');
	$(this).find('td').eq(12).attr('data-title','<b>DELTA</b> : ' + (arrBS[1] + arrBS[7]).toFixed(3) + '<br /><br/><b> PCR :</b> ' + (CurrentPCR_SP).toFixed(2) + '(' + (ChangeinPCR_SP*100).toFixed(2) + '%)');
  $(this).find('td').eq(18).attr('data-title',(PercentChangeinPutPrice*100).toFixed(2) + '%');
  $(this).find('td').eq(22).attr('data-title',(PercentChangeinPutOI*100).toFixed(2) + '%');
  $(this).find('td').eq(23).html(putPrem);
	$(this).find('td').eq(23).attr('data-title',PutGreek);
  if (StrikeValue == MaxPain){
    $(this).find('td').eq(12).attr('data-title','<b>DELTA</b> : ' + (arrBS[1] + arrBS[7]).toFixed(3) + '<br /><br /><b> PCR :</b> ' + (CurrentPCR_SP).toFixed(2) + '(' + (ChangeinPCR_SP*100).toFixed(2) + '%)<br /><br /><b> MaxPain (PCR Adj.) :</b> ' + (Math.ceil(MaxPainAdjusted/0.05)*.05).toFixed(2));
    
    
  }
  
  $(this).find('td').eq(23).after('<td class=paleGreen>' + (CurrentPCR_SP).toFixed(2) + '(' + (ChangeinPCR_SP*100).toFixed(2) + '%)'  + '</td>');
 // $(this).find('td').eq(24).html((CurrentPCR_SP).toFixed(2) + '(' + (ChangeinPCR_SP*100).toFixed(2) + '%)');
  
  
  var CurrentPCROI_SP = parseFloat($(this).find('td').eq(20).text().replace(',', '').replace(',', '').replace(',', ''))/parseFloat($(this).find('td').eq(4).text().replace(',', '').replace(',', '').replace(',', ''));
  //$(this).find('td').eq(25).html(CurrentPCROI_SP.toFixed(2));
  $(this).find('td').eq(24).after('<td class=paleGreen>' + CurrentPCROI_SP.toFixed(2)  + '</td>');
  
  console.log(StrikeValue + ' : '+ CurrentPCROI_SP.toFixed(2) + ' :: ' +  $(this).find('td').eq(25).text());
////console.log(SP_ATM + ":" + CallPriceChangeatATM + ":" + PutPriceChangeatATM);
//	//console.log(true,underlyingPrice,StrikeValue,timeLeft,0.1,avgCallIV,avgPutIV);
////console.log(StrikeValue, BlackScholes(true,underlyingPrice,StrikeValue,timeLeft,0.1,callIV),BlackScholes(false,underlyingPrice,StrikeValue,timeLeft,0.1,putIV));
////console.log(StrikeValue, black_scholes(true,underlyingPrice,StrikeValue,0.1,avgCallIV/100,timeLeft),black_scholes(false,underlyingPrice,StrikeValue,0.1,avgPutIV/100,timeLeft));
});
//---------------------------------------------------------------------------------------------------------------
$('#octable > tbody').find('tr').not(':last').each(function(){
  StrikeValue = parseFloat($(this).find('td').eq(12).text());
  if ($("#optnContract").val().toLowerCase().indexOf("select") === -1){

    if (Math.abs((StrikeValue - MaxPainAdjusted)/StrikeValue) <= 0.00075 ){
      $(this).find('td').eq(12).addClass('MaxPain').removeClass('grybg');
    }
    else {
      $(this).find('td').eq(12).removeClass('MaxPain').addClass('grybg');
    }
  }


});
$('#octable > tbody').find('tr').eq(HighestCallOI[1]).addClass('borderGreen');
$('#octable > tbody').find('tr').eq(HighestPutOI[1]).addClass('borderRed');


function GreekStatement(d,g,v,t,r){
	return '<b>DELTA:</b> ' + d.toFixed(4) + '<i class=littleText>(Change in Spot vs Strike Price)</i><hr /><b>GAMMA</b>:&emsp;&emsp;' + g.toFixed(4) + '<i class=littleText>(Change in Delta)</i><hr /> <b>VEGA</b>: &emsp;&emsp;&nbsp;' + v.toFixed(4) + '<i class=littleText>(Effect of Volatility)</i><hr /><b>THETA</b>:&emsp;&emsp;' + t.toFixed(4) + '<i class=littleText>(Effect of Time-Decay)</i><hr /><b>RHO:</b>&emsp;&emsp;&emsp;' + r.toFixed(4) +'<i class=littleText>(Effect of Interest Rate)</i>';
}

function Get_Stock_Sentiment(){
  var binary_number = -1;
  changeinPCR = PCR - ((TotalPutOption - (changeinITMPUTOI + changeinOTMPUTOI))/(TotalCallOption - (changeinITMCALLOI + changeinOTMCALLOI)));
  //console.log(changeinPCR);
  //console.log(TotalPutOption + " - " + (changeinITMPUTOI + changeinOTMPUTOI));
  //console.log(TotalCallOption + " - " + (changeinITMCALLOI + changeinOTMCALLOI));
  //console.log(PCR);
  //console.log(((TotalPutOption - (changeinITMPUTOI + changeinOTMPUTOI))/(TotalCallOption - (changeinITMCALLOI + changeinOTMCALLOI))));
  if (CallPriceChangeatATM > PutPriceChangeatATM){
    if ((changeinITMCALLOI + changeinOTMCALLOI) > 0){
        if ((changeinITMPUTOI + changeinOTMPUTOI) > 0){
          if (changeinPCR > 0){
            binary_number = 15;
          } // + + + +
          else{
            binary_number = 14;
          } // + + + -
        } //Increased Put OI
        else {
          if (changeinPCR < 0){
            binary_number = 12;
          } //+ + - -
        } //Decreased Put OI
    } // Increased Call OI
    else {
      if ((changeinITMPUTOI + changeinOTMPUTOI) > 0){
        if (changeinPCR > 0){
          binary_number = 11;
        } // + - + +
      } //Increased Put OI
      else {
        if (changeinPCR < 0){
          binary_number = 8;
        } //+ - - -
        else{
          binary_number = 9;
        } // + - - +
      } //Decreased Put OI
    } // Decreased Call OI
  } // Increased Price
  else {
    if ((changeinITMCALLOI + changeinOTMCALLOI) > 0){
        if ((changeinITMPUTOI + changeinOTMPUTOI) > 0){
          if (changeinPCR > 0){
            binary_number = 7;
          } // - + + +
          else{
            binary_number = 6;
          } // - + + -
        } //Increased Put OI
        else {
          if (changeinPCR < 0){
            binary_number = 4;
          } //- + - -
        } //Decreased Put OI
    } // Increased Call OI
    else {
      if ((changeinITMPUTOI + changeinOTMPUTOI) > 0){
        if (changeinPCR > 0){
          binary_number = 3;
        } // - - + +
      } //Increased Put OI
      else {
        if (changeinPCR < 0){
          binary_number = 0;
        } //- - - -
        else{
          binary_number = 1;
        } // - - - +
      } //Decreased Put OI
    } // Decreased Call OI
  } // Decreased Price
  //console.log((CallPriceChangeatATM > PutPriceChangeatATM)+' | ' + ((changeinITMCALLOI + changeinOTMCALLOI) > 0) + ' | ' + ((changeinITMPUTOI + changeinOTMPUTOI) > 0) + ' | ' + (changeinPCR > 0));
  return binary_number;
}

function Update_Comments(stockStatus){

  comments[15] = underlyingStock + ' witness Long Buildup and at the moment it is showing strong bullish sentiment which may sustain for tomorrow as well.';
  comments[14] = underlyingStock + ' witness Long Buildup right now and stays bullish but as per contra theory, sentiment may reverse in future as open interest is skewed more towards long call positions.';
  comments[12] = underlyingStock + ' shows Long Buildup happening but indicates bearish reversal to happen soon as open interest is shifting more towards call positions while put positions are reducing.';
  comments[11] = underlyingStock + ' shows Long Unwinding happening while it may remain bullish for sometime, it may become a range-bound entity as open interest is shifting more towards put positions than calls. Keep a watch on OpenInterest and Deliverable Quantity to reinforce the trend direction.';
  comments[9] = underlyingStock + ' illustrates Long Unwinding happening but clouds of uncertainity will keep it range-bound for sometime. Keep a watch on OpenInterest and Deliverable Quantity to reinforce the trend direction.';
  comments[8] = underlyingStock + ' numbers tells that Long Unwinding is happening and other numbers also suggest that bearish break-out may happen soon. Keep a watch on OpenInterest and Deliverable Quantity to reinforce the trend direction.';
  comments[7] = underlyingStock + ' witness buildup of short positions along with jump in put options in comparison to call options, if this sustained then stock may turn bullish or else it will remain range-bound.';
  comments[6] = 'Uncertainity builds up in the ' + underlyingStock + ' stock with short positions and it would remain range-bound for sometime. Keep a track on Moving averages, Volume and Deliverable quantity to confirm the trend.';
  comments[4] = underlyingStock + ' witness short covering and while it may remain bearish for sometime, it may become range-bound before catching a direction. Keep a close watch on deliverable traded quantity and volumes.';
  comments[3] = underlyingStock + ' tells that shorts are building up extensively and bullish reversal may happen soon as Open Interest is shifting towards Put options much more than Call options.';
  comments[1] = underlyingStock + ' shows the sign of short covering and will stay bearish for sometime until sentiment become range-bound or shows sign of reversal.';
  comments[0] = underlyingStock + ' witness short covering and large decrease in call options will support the bearish sentiment until next trading day.';

  OI_Price_Position[15] = 'Long BuildUp';
  OI_Price_Position[14] = 'Long BuildUp';
  OI_Price_Position[12] = 'Long BuildUp';
  OI_Price_Position[11] = 'Long Unwinding';
  OI_Price_Position[9] = 'Long Unwinding';
  OI_Price_Position[8] = 'Long Unwinding';
  OI_Price_Position[7] = 'Short Buildup';
  OI_Price_Position[6] = 'Short Buildup';
  OI_Price_Position[4] = 'Short Covering';
  OI_Price_Position[3] = 'Short Buildup';
  OI_Price_Position[1] = 'Short Covering';
  OI_Price_Position[0] = 'Short Covering';

  Sentiment[15] = 'Strong Bullish';
  Sentiment[14] = 'Bullish';
  Sentiment[12] = 'Bearish reversal';
  Sentiment[11] = 'range-bound';
  Sentiment[9] = 'range-bound';
  Sentiment[8] = 'Bearish breakout';
  Sentiment[7] = 'Bullish breakout';
  Sentiment[6] = 'range-bound';
  Sentiment[4] = 'range-bound';
  Sentiment[3] = 'Bullish reversal';
  Sentiment[1] = 'Bearish';
  Sentiment[0] = 'Strong Bearish';


  return comments[stockStatus];

}

   $('div#footer').append('<div id="OptionsTabs">\
  <ul>\
    <li><a href="#tabs-1">Glossary</a></li>\
    <li><a href="#tabs-2">Rules</a></li>\
	  <li><a href="#tabs-3">Strategy</a></li>\
  </ul>\
  <div id="tabs-1">\
    <p>\
	<ul>\
	<li><b>ASSIGNMENT: </b>The receipt of an exercise notice by an equity option seller (writer) that obligates him/her to sell (in the case of a short call) or buy (in the case of a short put) shares of underlying stock at the strike price per share.</li>\
	<li><b>AT-THE-MONEY: </b>An equity call or put option is at-the-money when its strike price is the same as the current underlying stock price.</li>\
	<li><b>BREAK-EVEN POINT: </b>An underlying stock price at which an option strategy will realize neither a profit nor a loss, generally at option expiration.</li>\
	<li><b>CALL OPTION: </b>An equity option that gives its buyer the <B><U>right</U></B> to buy shares of the underlying stock at the strike price per share at any time before it expires. The call seller (or writer), on the other hand, has the <B><U>obligation</U></B> to sell shares at the strike price if called upon to do so.</li>\
	<li><b>DELTA: </b>The amount a theoretical option’s price will change for a corresponding one-unit (point) change in the price of the underlying security.</li>\
	<li><b>STRIKE PRICE: </b>A term of any equity option contract, it is the price per share at which shares of stock will change hands after an option is exercised or assigned. Also referred to as the “exercise price,” or simply the “strike.”</li>\
	<li><b>GAMMA: </b>The amount a theoretical option’s delta will change for a corresponding one-unit (point) change in the price of the underlying security.</li>\
	<li><b>IMPLIED VOLATILITY: </b>An estimate of an underlying stock’s future volatility as predicted or implied by an option’s current market price. Implied volatility for any option can only be determined via an option pricing model.</li>\
	<li><b>IN-THE-MONEY: </b>An equity call contract is in-the-money when its strike price is less than the current underlying stock price.	An equity put contract is in-the-money when its strike price is greater than the current underlying stock price.</li>\
	<li><b>MARGIN REQUIREMENT: </b>The amount of cash and/or securities an option writer is required to deposit and maintain in a brokerage account to cover an uncovered (naked) short option position.	This cash can be seen as collateral pledged to the brokerage firm for the writer’s obligation to buy (in the case of a put) or sell (in the case of a call) shares of underlying stock in case of assignment.</li>\
	<li><b>OPTIONS PRICING MODEL: </b>A mathematical formula used to calculate an option’s theoretical value using as input its strike price, the underlying stock’s price, volatility and dividend amount, as well as time until expiration and risk-free interest rate.	Generated by an option pricing model are the option Greeks: delta, gamma, theta, vega and rho.	Well-known and widely used pricing models include the Black-Scholes, Cox-Ross-Rubinstein and Roll-Geske-Whaley.</li>\
	<li><b>OUT-OF-THE-MONEY: </b>An equity call option is out-of-the-money when its strike price is greater than the current underlying stock price. An equity put option is out-of-the-money when its strike price is less than the current underlying stock price.</li>\
	<li><b>PREMIUM: </b>The price paid or received for an option in the marketplace. Equity option premiums are quoted on a price-per-share basis, so the total premium amount paid by the buyer to the seller in any option transaction is equal to the quoted amount times 100 (underlying shares). Option premium consists of intrinsic value (if any) plus time value.</li>\
	<li><b>PUT OPTION: </b>An equity option that gives its buyer the right to sell 100 shares of the underlying stock at the strike price per share at any time before it expires. The put seller (or writer), on the other hand, has the obligation to buy 100 shares at the strike price if called upon to do so</li>\
	<li><b>RHO: </b>The amount a theoretical option’s price will change for a corresponding one-unit (percentage-point) change in the interest rate used to price the option contract.</li>\
	<li><b>ROLL-OVER: </b>To simultaneously close one option position and open another with the same underlying stock but a different strike price and/or expiration month. Rolling a long position involves selling those options and buying others. Rolling a short position involves buying the existing position and selling (writing) other options to create a new short position.</li>\
	<li><b>SPREAD: </b>A complex option position established by the purchase of one option and the sale of another option with the same underlying security.	The two options may be of the same or different types (calls/puts), and may have the same or different strike prices and/or expiration months.	A spread order is executed as a package, with both parts (legs) traded simultaneously, at a net debit, net credit, or for even money.</li>\
	<li><b>THETA: </b>The amount a theoretical option’s price will change for a corresponding one-unit (day) change in the days to expiration of the option contract.</li>\
	<li><b>TIME DECAY (EROSION): </b>A regular phenomenon in which the time value portion of an option’s price decays (decreases) with the passage of time. The rate of this decay increases as expiration gets closer, with the theoretical rate quantified by “theta,” one of the Greeks.</li>\
	<li><b>TIME VALUE: </b>For a call or put, it is the portion of the option’s premium (price) that exceeds its intrinsic value (in-the-money amount), if it has any. By definition, the premium of at- and out-of-the-money options consists only of time value. It is time value that is affected by time decay as well as changing volatility, interest rates and dividends.</li>\
	<li><b>VEGA: </b>The amount a theoretical option’s price will change for a corresponding one-unit (point) change in the implied volatility of the option contract.</li>\
	<li><b>VOLATILITY: </b>The fluctuation, up or down, in the price of a stock. It is measured mathematically as the annualized standard deviation of that stock’s daily price changes.</li>\
	<li><b>PUT-CALL PARITY: </b>Put/call parity states that the price of a call option implies a certain fair price for the corresponding put option with the same strike price and expiration (and vice versa). Support for this pricing relationship is based on the argument that arbitrage opportunities would exist whenever put and call prices diverged. The most simple formula for put/call parity is <b>Call – Put = Stock – Strike</b></li>\
	<li><b>PUT-CALL RATIO: </b>Put-call ratio (PCR) is an indicator commonly used to determine the mood of the options market. Being a contrarian indicator, the ratio looks at options buildup, helps traders understand whether a recent fall or rise in the market is excessive and if the time has come to take a contrarian call. The ratio is calculated either on the basis of options trading volumes or on the basis of options contracts on a given day or period.<br />\<br />Calculation of PCR is done by dividing the number of open interest in a Put contract by the number of open interest in Call option at the same strike price and expiry date on any given day. </li>\
	<li><b>MAX PAIN: </b>About 60% of options are traded out, 30% of options expire worthless and 10% of options are exercised. Max pain is the point where option owners feel "maximum pain," or will stand to lose the most money. Options sellers, on the other hand, may stand to reap the most reward.</li>\
	<li><b>PRICE INFLUENCERS: </b>Stock Price and Strike Price determine the intrinsic value and Time until expiration, volatility, interest rates, dividends determine extrinsic value. <br /><br />In general, as the price of the underlying increases, call prices increase and put prices decrease. Conversely, as the price of the underlying decreases, call prices decrease and put prices increase. <br /><br />The longer the time until expiration, the higher the option price.<br /><br />The greater the expected volatility, the higher the option value.<br /><br />Interest rates and dividends have small, but measurable, effects on option prices. In general, as interest rates rise, call premiums increase and put premiums decrease. <br /><br />If the underlying\'s dividend increases, call prices will decrease and put prices will increase. Conversely, if the underlying\'s dividend decreases, call prices will increase and put prices will decrease.</li>\
	</ul>\
	</p>\
  </div>\
  <div id="tabs-2">\
    <p>Most investors who are looking for ‘tips’ for option trading success have the wrong perspective. They seek tricks, special strategies, or ‘can’t-miss’ gimmicks. There are no such things. <br /><br />\
	<ol>\
	<li>Options are best used as risk-reducing investment tools, not instruments for gambling.</li>\
	<li>Use the <b>options Greeks to measure risk</b>.	</li>\
	<li>Do not hold any position than can – in the worst case scenario – cost more than you are willing to lose.</li>\
	<li><b>Do not buy options that are far out of the money</b> just because they are ‘cheap.’ The chances of success are tiny. Not zero, just tiny.</li>\
	<li><b>Hope is not a strategy.</b> When a position goes bad, consider reducing risk. Doing nothing and hoping for a good outcome is nothing more than gambling.</li>\
	<li><b>Limit losses.</b> The most effective way to accomplish that is to buy one option for every option you sell. That means selling spreads, rather than naked options.</li>\
	<li><b>Selling naked options is less risky than buying stock.</b> But, like stock ownership, there is considerable downside risk. Exception: It’s reasonable to sell naked puts – but only if you want to buy the shares, if assigned an exercise notice.</li>\
	<li>Always have a defined EXIT PLAN: We’re all creatures of habit — but some habits are worth breaking. Planning your exit isn’t just about minimizing loss on the downside if things go wrong. You should have an exit plan, period – even when a trade is going your way. You need to choose your upside exit point and downside exit point in advance.</li>\
	<li><b>Never makeup for past losses by doubling up</b>: What can sometimes make sense for stocks oftentimes does not fly in the options world.</li>\
	<li><b>Nevertrade illiquid options</b>:  Only 1 thing makes sense that is to trade options on stocks with high liquidity in the market.</li>\
	<li><b>Do not wait for expiry to buyback short strategies</b>: We can boil this mistake down to one piece of advice: Always be ready and willing to buy back short strategies early. When a trade is going your way, it can be easy to rest on your laurels and assume it will continue to do so. But remember, this will not always be the case. A trade that’s working in your favor can just as easily turn south.</li>\
	<li><b>SELL ON FRIDAY</b>If you are bullishon the stock then SELL PUT OPTION AT-THE-MONEY or if you are bearish then SELL CALL OPTION AT-THE-MONEY to reap benefits of TIME-DECAY. </li>\
	<li>OTM options start to lose their time premium faster in the 3rd & 4th week as the expiry approaches. So if you want to buy them, it better be before that or around mid month. The margin of error is narrow. For instance, if you buy OTM options in the last one week and you are wrong about the market direction, your premium will deteriorate into thin dust before you realize it.</li>\
	<li>ATM options have the highest premiums. I would say, buy them when you are doing short-term trades in the first half of the month.</li>\
	<li>ITM options are the safest as they have a large portion of intrinsic value. But the thing about them is that you have to select contracts which have liquidity.</li>\
	<li>Selling a put is less risky than selling a call simply because the underlying cannot go negative.</li>\
	<li>A short OTM call is riskier especially a naked one (i.e. non-covered)</li>\
	<li>Follow this order of buying/selling in order of depreciating reward probability: SELL PUTS (ITM -> ATM -> OTM); SELL COVERED CALL (ATM -> OTM); BUY CALL(ITM -> OTM); BUY PUT (ITM -> OTM)</li>\
	<li>Deep OTM options are nothing more than a lottery ticket with winning probability of less than 0.1%</li>\
	<li>If you are expecting volatility to increase then go for LONG STRADDLE/STRANGLE/REVERSE IRON CONDOR strategy else if you are expecting volatility to reduce then go for SHORT STRADDLE/STRANGLE/IRON CONDOR strategy.</li>\
	<li>WEEK #01: Try to profit from a directional move, buy at-the-time / just in-the-time options. SELL all positions on Friday.</li>\
	<li>WEEK #02: Exit from profitable long legs if volatility is reducing or short legs if volatility is increasing. SELL all positions on Friday. Start writing positions against the directional move. If Bullish then write PUT options, if BEARISH then write CALL options.</li>\
	<li>WEEK #03: Refrain buying fresh positions. Infact, unless you are very bullish or very bearish on a stock and  very very confident on your conviction, only then keep the existing options else book your losses. Try selecting liquid bull stocks and sell their OTM PUTS. If you are selling OTM CALL option (bearish outlook), always cover it. It may limit your gains but will save you from horrible and deadly losses.</li>\
	<li>WEEK #04: Cover your positions. Follow the rule of Week #03: Refrain buying fresh options (Call or Put).</li>\
	</ol></p>\
  </div>\
  <div id="tabs-3"><div style="margin-top:20px;"></div><hr />\
  <strong>Sentiment: </strong>' + Update_Comments(Get_Stock_Sentiment()) + '<br /> <br /><hr/><br/><br/>\
<table>\
   <thead><tr><th colspan="8" style="text-align:center"><strong>Profitable OPTION STRATEGIES</strong></th></tr>\
		<tr>\
		<th>Name</th>\
		<th>Action</th>\
		<th>Net Debit</th>\
		<th>Max. Loss</th>\
		<th>Max. Profit</th>\
		<th>Breakeven Point(s)</th>\
		<th>Outlook</th>\
		<th>Risk/Reward</th>\
		</tr>\
   </thead>\
   <tbody>\
		<tr><td>Short Call Butterfly</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Reverse Iron Condor</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Strip</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Strap</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Put Ratio Back Spread</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Call Ratio Back Spread</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Bull Put Spread</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Bear Call Spread</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Bull Call Spread</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Bear Put Spread</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Bear Put Ladder</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Bear Call Ladder</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Long Put Butterfly</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Long Strangle</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Long Straddle</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
		<tr><td>Long Guts</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\
   </tbody>\
   </table>\
  </div>\
</div>\
   ');
